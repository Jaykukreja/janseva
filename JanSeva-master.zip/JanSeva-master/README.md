# JanSeva
Dependency tree:


Server:
Node Js
Express Js

Database:
MySQL

Android:
