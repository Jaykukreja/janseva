The code contains a lot of bugs and is yet to be tested.
Two main functions :- Apply schemes
                      Eligible schems
are yet to be implemented.
Will be updating the code soon.
